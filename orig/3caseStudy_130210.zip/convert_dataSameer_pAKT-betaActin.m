
global BreastVariables
if isempty('BreastVariables'); LoadBreastVariables;end


%%
maxValue = 1e4;

[~,CLNames] = xlsread('BrCa 48 - Akt-P-S473 (CST 4060) - UPDATED.xlsx' ,'ANALYSIS', ...
    'b2:b49');
CLNames = lower(ReducName(CLNames));

files = {'BrCa 48 - Akt-P-S473 (CST 4060) - UPDATED.xlsx' 
    'BrCa 48 - Beta Actin (CST 3700).xlsx'};

data = {};
props = {};
for idata = 1:5
    disp([62+idata*5 '2:' 65+idata*5 '49'])
    data{idata} = xlsread(files{1},'ANALYSIS', ...
        [62+idata*5 '2:' 65+idata*5 '49']);
    data{idata}(isnan(data{idata})) = maxValue;
    if idata<3
        date = '121109';
    elseif idata<5
        date = '1301170';
    else
        date = '130110';
    end
    % props = [kinase, trans_time, date, replicate]
    props{idata} = {'Akt pS437' 30+(15*(idata<5)) date mod(idata-1,2)+1};
end
shift = length(data);

%%
zones = ['cd'; 'fh'; 'jl'; 'no'];
for idata = 1:4
    disp([zones(idata,1) '2:' zones(idata,2) '49'])
    data{idata+shift} = xlsread(files{2},'Summary', ...
        [zones(idata,1) '2:' zones(idata,2) '49']);
    data{idata+shift}(isnan(data{idata})) = maxValue;
   
    % props = [kinase, trans_time, date, replicate]
    props{idata+shift} = {'beta actin' 45 '130125' idata};
end


%%

outfile = fopen('Data_Sameer.tsv','w');
fprintf(outfile, ['######## header legend\n' ...
    'cell_line\tstring\tName of the cell line\n' ...
    'kinase\tstring\tName of the kinase measures, with phosphosite\n' ...
    'scan_int\tfloat\tScanning intensity\n' ...
    'trans_time\tfloat\tTRansfer time for the western blot\n' ...
    'date\tfloat\tdate of the experiment in format YYMMDD\n' ...
    'replicate\tfloat\n' ...
    'intensity\tfloat\tSignal intensity measured with the scanner\n'])
fprintf(outfile, '******\tdata\t*****\t*****\n')
for idata = 1:length(data)
    for i=1:length(CLNames)
        for j=1:size(data{idata},2)
            fprintf(outfile, '%s\t%s\t%.2f\t%.5f\t%s\t%i\t%.5f\n', ...
                CLNames{i}, props{idata}{1}, 2.5*(j+(size(data{idata},2)<3)), props{idata}{2}, ...
                props{idata}{3}, props{idata}{4}, data{idata}(i,j));
        end
    end
end
pause(.5)
fclose(outfile)
            
            