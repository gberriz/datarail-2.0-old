% loading the reference for #cell/signal

[num, label] = xlsread('BreastLinesFirstBatch_MGHData_sent.xlsx','RefSeedSignal','a2:v14');
%%
figure(1)
clf
loglog([50 1e5], [50 1e5], '-r')
hold on
for i=2:22
h = loglog(num(:,1),num(:,i),'-k.');
pause(1)
set(h,'color',[.7 .7 .7],'marker','none')
xlim([0 1e5])
ylim([0 1e5])
end